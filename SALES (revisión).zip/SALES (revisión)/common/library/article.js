"use strict";
exports.__esModule = true;
exports.Article = void 0;
var Article = /** @class */ (function () {
    function Article() {
    }
    return Article;
}());
exports.Article = Article;
